package com.mensal.compras;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoControleMensalDeComprasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoControleMensalDeComprasApplication.class, args);
	}

}
